"""AdigiPQR offline: serves this folder on http://127.0.0.1:8765/ for this PC only and opens the browser.
JavaScript types are set explicitly: Windows can map .js/.mjs to text/plain in the registry, which breaks the
PDF reader (a JavaScript module)."""
import functools
import http.server
import os
import webbrowser

PORT = 8765
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.dirname(os.path.abspath(__file__)))
H.func.extensions_map.update({'.js': 'text/javascript', '.mjs': 'text/javascript', '.wasm': 'application/wasm',
                              '.svg': 'image/svg+xml', '.gz': 'application/gzip'})
srv = http.server.ThreadingHTTPServer(('127.0.0.1', PORT), H)
print(f'AdigiPQR is running at http://127.0.0.1:{PORT}/ (this PC only; nothing is uploaded). Close this window to stop.')
webbrowser.open(f'http://127.0.0.1:{PORT}/')
srv.serve_forever()
