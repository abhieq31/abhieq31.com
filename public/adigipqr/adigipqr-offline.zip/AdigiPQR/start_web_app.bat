@echo off
rem Opens the AdigiPQR web app from this folder, fully offline: a local web server for this PC only (needs Python).
rem Reading BMR scans needs this (browsers block OCR workers on pages opened as files);
rem the APQR sheet itself also works by double-clicking index.html.
cd /d "%~dp0"
python serve.py
if errorlevel 1 pause
